'use strict';
const express = require('express');
const bcrypt  = require('bcryptjs');
const pool    = require('../db');

const router = express.Router();

// ── POST /api/auth/reset-password ─────────────────────────────────────────────
// Body: { role: 'patient'|'doctor', mobile, newPassword }
router.post('/', async (req, res) => {
  try {
    const { role, mobile, newPassword } = req.body;

    if (!role || !mobile || !newPassword) {
      return res.status(400).json({ message: 'role, mobile and newPassword are required.' });
    }
    if (!['patient', 'doctor'].includes(role)) {
      return res.status(400).json({ message: 'role must be "patient" or "doctor".' });
    }
    if (!/^[0-9]{10}$/.test(mobile)) {
      return res.status(400).json({ message: 'Mobile must be exactly 10 digits.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters.' });
    }

    const table  = role === 'doctor' ? 'doctors' : 'patients';
    const pkCol  = role === 'doctor' ? 'doctor_id' : 'patient_id';

    // Check account exists
    const [rows] = await pool.query(
      `SELECT ${pkCol} FROM ${table} WHERE mobile = ? LIMIT 1`,
      [mobile]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'No account found with that mobile number.' });
    }

    const hash = await bcrypt.hash(newPassword, 10);
    await pool.query(
      `UPDATE ${table} SET password = ? WHERE mobile = ?`,
      [hash, mobile]
    );

    const loginPage = role === 'doctor' ? 'doctor-login.html' : 'login.html';
    return res.json({ message: 'Password updated successfully. Please sign in.', redirect: loginPage });
  } catch (err) {
    console.error('Reset password error:', err);
    return res.status(500).json({ message: 'Server error during password reset.' });
  }
});

module.exports = router;
