
'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

const VALID_QUALIFICATIONS = ['MBBS', 'BHMS', 'BAMS', 'MD', 'MS'];

const VALID_SPECIALIZATIONS = [
  'General Medicine',
  'Cardiology',
  'Dermatology',
  'Pediatrics',
  'Orthopedics',
  'Neurology',
  'Other'
];

function signToken(doctor) {
  return jwt.sign(
    {
      id: doctor.doctor_id,
      role: 'doctor',
      mobile: doctor.mobile,
      name: doctor.name
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// DOCTOR REGISTRATION
router.post('/register', async (req, res) => {
  try {
    const {
      name,
      qualification,
      specialization,
      mobile,
      email,
      password,
      gender
    } = req.body;

    if (!name || !qualification || !specialization ||
        !mobile || !email || !password) {
      return res.status(400).json({
        message: 'All required fields must be filled.'
      });
    }

    if (!/^[0-9]{10}$/.test(mobile)) {
      return res.status(400).json({
        message: 'Mobile must be exactly 10 digits.'
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        message: 'Password must be at least 8 characters.'
      });
    }

    if (!VALID_QUALIFICATIONS.includes(qualification)) {
      return res.status(400).json({
        message: 'Invalid qualification value.'
      });
    }

    if (!VALID_SPECIALIZATIONS.includes(specialization)) {
      return res.status(400).json({
        message: 'Invalid specialization value.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    const [existing] = await pool.query(
      'SELECT doctor_id FROM doctors WHERE mobile = ? OR email = ? LIMIT 1',
      [mobile, cleanEmail]
    );

    if (existing.length) {
      return res.status(409).json({
        message: 'An account with this mobile or email already exists. Please sign in.'
      });
    }

    const cleanName = name.trim();
    const initials = cleanName
      .split(/\s+/)
      .map(word => word[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();

    const hash = await bcrypt.hash(password, 10);

    const [result] = await pool.query(
      `INSERT INTO doctors
       (name, qualification, specialization, gender, mobile, email, password, initials)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        cleanName,
        qualification,
        specialization,
        gender || null,
        mobile,
        cleanEmail,
        hash,
        initials
      ]
    );

    const doctor = {
      doctor_id: result.insertId,
      name: cleanName,
      mobile
    };

    return res.status(201).json({
      token: signToken(doctor),
      doctor: {
        id: doctor.doctor_id,
        name: doctor.name,
        mobile: doctor.mobile
      }
    });
  } catch (err) {
    console.error('Doctor register error:', err);
    return res.status(500).json({
      message: 'Server error during registration.'
    });
  }
});

// DOCTOR LOGIN
router.post('/login', async (req, res) => {
  try {
    const { mobile, password } = req.body;

    if (!mobile || !password) {
      return res.status(400).json({
        message: 'Mobile and password are required.'
      });
    }

    const [rows] = await pool.query(
      `SELECT doctor_id, name, mobile, password
       FROM doctors
       WHERE mobile = ?
       LIMIT 1`,
      [mobile]
    );

    if (!rows.length) {
      return res.status(401).json({
        message: 'Account not found or details do not match.'
      });
    }

    const doctor = rows[0];
    const match = await bcrypt.compare(password, doctor.password);

    if (!match) {
      return res.status(401).json({
        message: 'Account not found or details do not match.'
      });
    }

    return res.json({
      token: signToken(doctor),
      doctor: {
        id: doctor.doctor_id,
        name: doctor.name,
        mobile: doctor.mobile
      }
    });
  } catch (err) {
    console.error('Doctor login error:', err);
    return res.status(500).json({
      message: 'Server error during login.'
    });
  }
});

// GET DOCTOR PROFILE
router.get('/profile', verifyToken('doctor'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT doctor_id AS id, name, qualification, specialization,
              gender, mobile, email, initials
       FROM doctors
       WHERE doctor_id = ?
       LIMIT 1`,
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({
        message: 'Doctor profile not found.'
      });
    }

    return res.json({ doctor: rows[0] });
  } catch (err) {
    console.error('Get doctor profile error:', err);
    return res.status(500).json({
      message: 'Unable to fetch doctor profile.'
    });
  }
});

// UPDATE DOCTOR PROFILE
router.put('/profile', verifyToken('doctor'), async (req, res) => {
  try {
    const {
      name,
      qualification,
      specialization,
      gender,
      email
    } = req.body;

    if (!name || !qualification || !specialization || !email) {
      return res.status(400).json({
        message: 'Name, qualification, specialization and email are required.'
      });
    }

    if (!VALID_QUALIFICATIONS.includes(qualification)) {
      return res.status(400).json({
        message: 'Invalid qualification.'
      });
    }

    if (!VALID_SPECIALIZATIONS.includes(specialization)) {
      return res.status(400).json({
        message: 'Invalid specialization.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    const [existing] = await pool.query(
      `SELECT doctor_id
       FROM doctors
       WHERE email = ? AND doctor_id != ?
       LIMIT 1`,
      [cleanEmail, req.user.id]
    );

    if (existing.length) {
      return res.status(409).json({
        message: 'This email is already used by another account.'
      });
    }

    const initials = cleanName
      .split(/\s+/)
      .map(word => word[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();

    await pool.query(
      `UPDATE doctors
       SET name = ?, qualification = ?, specialization = ?,
           gender = ?, email = ?, initials = ?
       WHERE doctor_id = ?`,
      [
        cleanName,
        qualification,
        specialization,
        gender || null,
        cleanEmail,
        initials,
        req.user.id
      ]
    );

    const [rows] = await pool.query(
      `SELECT doctor_id AS id, name, qualification, specialization,
              gender, mobile, email, initials
       FROM doctors
       WHERE doctor_id = ?
       LIMIT 1`,
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({
        message: 'Doctor profile not found.'
      });
    }

    return res.json({
      message: 'Doctor profile updated successfully.',
      doctor: rows[0]
    });
  } catch (err) {
    console.error('Update doctor profile error:', err);
    return res.status(500).json({
      message: 'Unable to update doctor profile.'
    });
  }
});

module.exports = router;
