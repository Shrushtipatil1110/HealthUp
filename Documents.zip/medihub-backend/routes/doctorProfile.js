'use strict';
const express     = require('express');
const pool        = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

const VALID_SPECIALIZATIONS = ['General Medicine', 'Cardiology', 'Dermatology', 'Pediatrics', 'Orthopedics', 'Neurology', 'Other'];

// ── GET /api/doctor/profile ────────────────────────────────────────────────────
// Returns the logged-in doctor's own profile.
router.get('/profile', verifyToken('doctor'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT doctor_id AS id, name, qualification, specialization, gender,
              mobile, email, license_no AS licenseNo, experience, fee, available, initials,
              created_at AS createdAt
       FROM doctors
       WHERE doctor_id = ? LIMIT 1`,
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Doctor profile not found.' });
    }
    return res.json(rows[0]);
  } catch (err) {
    console.error('Get doctor profile error:', err);
    return res.status(500).json({ message: 'Server error fetching profile.' });
  }
});

// ── PATCH /api/doctor/profile ──────────────────────────────────────────────────
// Doctor updates their own profile (name, specialization, etc.).
// mobile cannot be changed (it is used for login).
router.patch('/profile', verifyToken('doctor'), async (req, res) => {
  try {
    const { name, qualification, specialization, gender, email, licenseNo } = req.body;
    const doctorId = req.user.id;

    if (specialization && !VALID_SPECIALIZATIONS.includes(specialization)) {
      return res.status(400).json({ message: 'Invalid specialization value.' });
    }

    // Build SET clause dynamically for provided fields only
    const fields = [];
    const values = [];

    if (name)           { fields.push('name = ?');           values.push(name.trim()); }
    if (qualification)  { fields.push('qualification = ?');  values.push(qualification); }
    if (specialization) { fields.push('specialization = ?'); values.push(specialization); }
    if (gender)         { fields.push('gender = ?');         values.push(gender); }
    if (email)          { fields.push('email = ?');          values.push(email.trim().toLowerCase()); }
    if (licenseNo !== undefined) { fields.push('license_no = ?'); values.push(licenseNo || null); }

    // Update initials if name changed
    if (name) {
      const initials = name.trim().split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
      fields.push('initials = ?');
      values.push(initials);
    }

    if (fields.length === 0) {
      return res.status(400).json({ message: 'No fields provided to update.' });
    }

    values.push(doctorId);
    await pool.query(
      `UPDATE doctors SET ${fields.join(', ')} WHERE doctor_id = ?`,
      values
    );

    // Return updated profile
    const [rows] = await pool.query(
      `SELECT doctor_id AS id, name, qualification, specialization, gender,
              mobile, email, license_no AS licenseNo, experience, fee, available, initials
       FROM doctors WHERE doctor_id = ? LIMIT 1`,
      [doctorId]
    );

    return res.json({ message: 'Profile updated.', doctor: rows[0] });
  } catch (err) {
    console.error('Update doctor profile error:', err);
    return res.status(500).json({ message: 'Server error updating profile.' });
  }
});

// ── GET /api/doctor/patients ───────────────────────────────────────────────────
// Returns distinct patients who have booked this doctor, derived from appointments.
router.get('/patients', verifyToken('doctor'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT
         a.patient_mobile AS mobile,
         a.patient_name   AS name,
         COUNT(*)         AS appointmentCount,
         MAX(a.date)      AS latestVisit
       FROM appointments a
       WHERE a.doctor_id = ?
       GROUP BY a.patient_mobile, a.patient_name
       ORDER BY latestVisit DESC`,
      [req.user.id]
    );
    return res.json(rows);
  } catch (err) {
    console.error('Get doctor patients error:', err);
    return res.status(500).json({ message: 'Server error fetching patients.' });
  }
});

module.exports = router;
