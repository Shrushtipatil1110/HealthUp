'use strict';
const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const pool    = require('../db');

const router = express.Router();

// ── Helper ────────────────────────────────────────────────────────────────────
function signToken(patient) {
  return jwt.sign(
    { id: patient.patient_id, role: 'patient', mobile: patient.mobile, name: patient.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// ── POST /api/auth/patient/register ──────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { name, age, gender, address, mobile, email, password } = req.body;

    // Basic presence validation
    if (!name || !age || !gender || !address || !mobile || !email || !password) {
      return res.status(400).json({ message: 'All fields are required.' });
    }
    if (!/^[0-9]{10}$/.test(mobile)) {
      return res.status(400).json({ message: 'Mobile must be exactly 10 digits.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters.' });
    }
    if (!['Male', 'Female', 'Other'].includes(gender)) {
      return res.status(400).json({ message: 'Invalid gender value.' });
    }

    // Check for duplicate mobile or email
    const [existing] = await pool.query(
      'SELECT patient_id FROM patients WHERE mobile = ? OR email = ? LIMIT 1',
      [mobile, email]
    );
    if (existing.length > 0) {
      return res.status(409).json({ message: 'An account with this mobile or email already exists. Please sign in.' });
    }

    // Hash password and insert
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO patients (name, age, gender, address, mobile, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name.trim(), Number(age), gender, address.trim(), mobile, email.trim().toLowerCase(), hash]
    );

    const newPatient = { patient_id: result.insertId, name: name.trim(), mobile };
    return res.status(201).json({ token: signToken(newPatient), patient: { id: newPatient.patient_id, name: newPatient.name, mobile } });
  } catch (err) {
    console.error('Patient register error:', err);
    return res.status(500).json({ message: 'Server error during registration.' });
  }
});

// ── POST /api/auth/patient/login ──────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { mobile, password } = req.body;

    if (!mobile || !password) {
      return res.status(400).json({ message: 'Mobile and password are required.' });
    }

    const [rows] = await pool.query(
      'SELECT patient_id, name, mobile, password FROM patients WHERE mobile = ? LIMIT 1',
      [mobile]
    );
    if (rows.length === 0) {
      return res.status(401).json({ message: 'Account not found or details do not match. Register first if this is your first visit.' });
    }

    const patient = rows[0];
    const match   = await bcrypt.compare(password, patient.password);
    if (!match) {
      return res.status(401).json({ message: 'Account not found or details do not match. Register first if this is your first visit.' });
    }

    return res.json({ token: signToken(patient), patient: { id: patient.patient_id, name: patient.name, mobile: patient.mobile } });
  } catch (err) {
    console.error('Patient login error:', err);
    return res.status(500).json({ message: 'Server error during login.' });
  }
});

module.exports = router;
