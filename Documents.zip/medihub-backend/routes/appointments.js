'use strict';
const express     = require('express');
const { v4: uuidv4 } = require('uuid');
const pool        = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

const VALID_STATUSES = ['Pending', 'Accepted', 'Rejected'];

// ── POST /api/appointments ─────────────────────────────────────────────────────
// Patient books an appointment. Body: { doctorId, date, time, reason }
router.post('/', verifyToken('patient'), async (req, res) => {
  try {
    const { doctorId, date, time, reason } = req.body;
    const patientId = req.user.id;

    if (!doctorId || !date || !time || !reason) {
      return res.status(400).json({ message: 'doctorId, date, time and reason are required.' });
    }

    // Fetch doctor details for denormalised columns
    const [doctorRows] = await pool.query(
      'SELECT doctor_id, name, mobile, specialization FROM doctors WHERE doctor_id = ? LIMIT 1',
      [doctorId]
    );
    if (doctorRows.length === 0) {
      return res.status(404).json({ message: 'Doctor not found.' });
    }
    const doctor = doctorRows[0];

    // Fetch patient details
    const [patientRows] = await pool.query(
      'SELECT patient_id, name, mobile FROM patients WHERE patient_id = ? LIMIT 1',
      [patientId]
    );
    const patient = patientRows[0];

    const uuid = uuidv4();

    await pool.query(
      `INSERT INTO appointments
         (uuid, patient_id, doctor_id, patient_name, patient_mobile,
          doctor_name, specialization, date, time, reason, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
      [uuid, patientId, doctor.doctor_id,
       patient.name, patient.mobile,
       doctor.name, doctor.specialization,
       date, time, reason]
    );

    return res.status(201).json({
      message: 'Appointment request saved.',
      appointment: {
        id: uuid, patientName: patient.name, patientMobile: patient.mobile,
        doctorName: doctor.name, specialization: doctor.specialization,
        date, time, reason, status: 'Pending',
        createdAt: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('Book appointment error:', err);
    return res.status(500).json({ message: 'Server error booking appointment.' });
  }
});

// ── GET /api/appointments/mine ─────────────────────────────────────────────────
// Returns all appointments for the logged-in patient.
router.get('/mine', verifyToken('patient'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT uuid AS id, patient_name AS patientName, patient_mobile AS patientMobile,
              doctor_name AS doctorName, specialization, date, time, reason, status,
              created_at AS createdAt
       FROM appointments
       WHERE patient_id = ?
       ORDER BY date ASC, time ASC`,
      [req.user.id]
    );
    return res.json(rows);
  } catch (err) {
    console.error('Get patient appointments error:', err);
    return res.status(500).json({ message: 'Server error fetching appointments.' });
  }
});

// ── GET /api/appointments/doctor ───────────────────────────────────────────────
// Returns all appointments for the logged-in doctor.
router.get('/doctor', verifyToken('doctor'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT uuid AS id, patient_name AS patientName, patient_mobile AS patientMobile,
              doctor_name AS doctorName, specialization, date, time, reason, status,
              created_at AS createdAt
       FROM appointments
       WHERE doctor_id = ?
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    return res.json(rows);
  } catch (err) {
    console.error('Get doctor appointments error:', err);
    return res.status(500).json({ message: 'Server error fetching appointments.' });
  }
});

// ── PATCH /api/appointments/:uuid/status ───────────────────────────────────────
// Doctor accepts or rejects an appointment.
router.patch('/:uuid/status', verifyToken('doctor'), async (req, res) => {
  try {
    const { uuid } = req.params;
    const { status } = req.body;

    if (!VALID_STATUSES.includes(status)) {
      return res.status(400).json({ message: 'status must be Pending, Accepted or Rejected.' });
    }

    // Only update if this appointment belongs to this doctor
    const [result] = await pool.query(
  'UPDATE appointments SET status = ? WHERE uuid = ? AND doctor_id = ?',
  [status, uuid, req.user.id]
);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Appointment not found or not authorised.' });
    }

    return res.json({ message: `Appointment ${status.toLowerCase()}.`, status });
  } catch (err) {
    console.error('Update appointment status error:', err);
    return res.status(500).json({ message: 'Server error updating appointment.' });
  }
});

module.exports = router;
