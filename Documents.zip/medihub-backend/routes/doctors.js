'use strict';
const express     = require('express');
const pool        = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

// ── GET /api/doctors ──────────────────────────────────────────────────────────
// Returns all doctor profiles (no password) for the specialist page.
// Protected so only logged-in patients can see the list.
router.get('/', verifyToken('patient'), async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT doctor_id AS id, name, specialization AS specialty,
              experience, fee, available, initials, qualification, gender
       FROM doctors
       ORDER BY name ASC`
    );
    return res.json(rows);
  } catch (err) {
    console.error('Get doctors error:', err);
    return res.status(500).json({ message: 'Server error fetching doctors.' });
  }
});

module.exports = router;
