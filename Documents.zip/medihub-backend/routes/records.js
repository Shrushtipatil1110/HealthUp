'use strict';

const express = require('express');
const pool = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

router.get('/mine', verifyToken('patient'), async (req, res) => {
  try {
    const patientId = req.user.id || req.user.patientId;

    if (!patientId) {
      return res.status(401).json({ message: 'Patient ID missing from token.' });
    }

    const [rows] = await pool.query(
      `SELECT id, title, DATE_FORMAT(record_date, '%Y-%m-%d') AS date,
              notes, created_at AS createdAt
       FROM medical_records
       WHERE patient_id = ?
       ORDER BY record_date DESC, id DESC`,
      [patientId]
    );

    res.json(rows);
  } catch (error) {
    console.error('Load medical records:', error);
    res.status(500).json({ message: 'Unable to load medical records.' });
  }
});

router.post('/', verifyToken('patient'), async (req, res) => {
  try {
    const patientId = req.user.id || req.user.patientId;
    const { title, date, notes } = req.body;

    if (!patientId) {
      return res.status(401).json({ message: 'Patient ID missing from token.' });
    }

    if (!title?.trim() || !date || !notes?.trim() ||
        !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ message: 'Enter a valid title, date and notes.' });
    }

    const [result] = await pool.query(
      `INSERT INTO medical_records (patient_id, title, record_date, notes)
       VALUES (?, ?, ?, ?)`,
      [patientId, title.trim(), date, notes.trim()]
    );

    res.status(201).json({
      message: 'Medical record saved.',
      record: { id: result.insertId, title: title.trim(), date, notes: notes.trim() }
    });
  } catch (error) {
    console.error('Save medical record:', error);
    res.status(500).json({ message: 'Unable to save medical record.' });
  }
});

router.delete('/:id', verifyToken('patient'), async (req, res) => {
  try {
    const patientId = req.user.id || req.user.patientId;

    if (!patientId) {
      return res.status(401).json({ message: 'Patient ID missing from token.' });
    }

    const [result] = await pool.query(
      'DELETE FROM medical_records WHERE id = ? AND patient_id = ?',
      [req.params.id, patientId]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ message: 'Record not found.' });
    }

    res.json({ message: 'Medical record deleted.' });
  } catch (error) {
    console.error('Delete medical record:', error);
    res.status(500).json({ message: 'Unable to delete medical record.' });
  }
});

module.exports = router;