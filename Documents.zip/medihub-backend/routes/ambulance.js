
'use strict';

const express = require('express');
const pool = require('../db');
const verifyToken = require('../middleware/auth');

const router = express.Router();

router.get('/mine', verifyToken('patient'), async (req, res) => {
  try {
    const patientId = req.user.id || req.user.patientId;

    if (!patientId) {
      return res.status(401).json({ message: 'Patient ID missing from token.' });
    }

    const [rows] = await pool.query(
      `SELECT id, address, phone, urgency, details, status,
              created_at AS createdAt
       FROM ambulance_requests
       WHERE patient_id = ?
       ORDER BY created_at DESC`,
      [patientId]
    );

    res.json(rows);
  } catch (error) {
    console.error('Load ambulance requests:', error);
    res.status(500).json({ message: 'Unable to load ambulance requests.' });
  }
});

router.post('/', verifyToken('patient'), async (req, res) => {
  try {
    const patientId = req.user.id || req.user.patientId;
    const { address, phone, urgency, details = '' } = req.body;

    if (!patientId) {
      return res.status(401).json({ message: 'Patient ID missing from token.' });
    }

    if (!address?.trim() || !/^[0-9]{10}$/.test(phone || '') || !urgency) {
      return res.status(400).json({ message: 'Enter a valid address, 10-digit phone number and urgency.' });
    }

    const [result] = await pool.query(
      `INSERT INTO ambulance_requests
       (patient_id, address, phone, urgency, details)
       VALUES (?, ?, ?, ?, ?)`,
      [patientId, address.trim(), phone, urgency, details.trim()]
    );

    const [rows] = await pool.query(
      `SELECT id, address, phone, urgency, details, status,
              created_at AS createdAt
       FROM ambulance_requests WHERE id = ?`,
      [result.insertId]
    );

    res.status(201).json({
      message: 'Ambulance request saved.',
      request: rows[0]
    });
  } catch (error) {
    console.error('Save ambulance request:', error);
    res.status(500).json({ message: 'Unable to save ambulance request.' });
  }
});

module.exports = router;
