-- ============================================================
--  MediHub schema.sql
--  Run this ONCE to create the four new tables.
--  The `patients` table already exists and is NOT included here.
--  Safe to re-run: all statements use CREATE TABLE IF NOT EXISTS.
-- ============================================================

USE medihub;

-- ------------------------------------------------------------
--  doctors
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS doctors (
  doctor_id       INT            AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100)   NOT NULL,
  qualification   VARCHAR(10)    NOT NULL,   -- MBBS | BHMS | BAMS | MD | MS
  specialization  VARCHAR(100)   NOT NULL,
  gender          VARCHAR(20),
  mobile          VARCHAR(10)    UNIQUE NOT NULL,
  email           VARCHAR(100)   UNIQUE NOT NULL,
  password        VARCHAR(255)   NOT NULL,   -- bcrypt hash
  license_no      VARCHAR(100),
  experience      VARCHAR(50),               -- e.g. "12 years"
  fee             DECIMAL(8,2),              -- e.g. 700.00
  available       VARCHAR(100),              -- e.g. "Mon-Fri"
  initials        VARCHAR(5),                -- e.g. "AK"
  created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
--  appointments
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
  appointment_id  INT            AUTO_INCREMENT PRIMARY KEY,
  uuid            VARCHAR(36)    UNIQUE NOT NULL,   -- JS-facing id (crypto.randomUUID)
  patient_id      INT            NOT NULL,
  doctor_id       INT            NOT NULL,
  patient_name    VARCHAR(100),
  patient_mobile  VARCHAR(10),
  doctor_name     VARCHAR(100),
  specialization  VARCHAR(100),
  date            DATE           NOT NULL,
  time            VARCHAR(20)    NOT NULL,
  reason          TEXT,
  status          VARCHAR(20)    NOT NULL DEFAULT 'Pending', -- Pending|Accepted|Rejected
  created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)   ON DELETE CASCADE
);

-- ------------------------------------------------------------
--  ambulance_requests
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ambulance_requests (
  request_id      INT            AUTO_INCREMENT PRIMARY KEY,
  patient_id      INT            NOT NULL,
  patient_mobile  VARCHAR(10),
  address         VARCHAR(300)   NOT NULL,
  phone           VARCHAR(10)    NOT NULL,
  urgency         VARCHAR(100)   NOT NULL,
  details         TEXT,
  created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
--  medical_records
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS medical_records (
  record_id       INT            AUTO_INCREMENT PRIMARY KEY,
  patient_id      INT            NOT NULL,
  patient_mobile  VARCHAR(10),
  title           VARCHAR(200)   NOT NULL,
  date            DATE           NOT NULL,
  notes           TEXT           NOT NULL,
  created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);
