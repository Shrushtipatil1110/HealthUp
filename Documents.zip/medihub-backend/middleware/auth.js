'use strict';
const jwt = require('jsonwebtoken');

/**
 * verifyToken(role)
 * Returns an Express middleware that:
 *  1. Checks for a valid JWT in the Authorization header.
 *  2. Optionally checks that the token role matches the required role.
 *
 * Usage:
 *   router.get('/mine', verifyToken('patient'), handler);
 *   router.get('/doctor', verifyToken('doctor'), handler);
 */
function verifyToken(role) {
  return (req, res, next) => {
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
      return res.status(401).json({ message: 'No token provided. Please log in.' });
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // If a specific role is required, enforce it
      if (role && decoded.role !== role) {
        return res.status(403).json({ message: 'Access denied: insufficient role.' });
      }

      req.user = decoded; // { id, role, mobile, name }
      next();
    } catch (err) {
      return res.status(401).json({ message: 'Invalid or expired token. Please log in again.' });
    }
  };
}

module.exports = verifyToken;
