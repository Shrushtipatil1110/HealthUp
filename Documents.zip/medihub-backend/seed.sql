-- ============================================================
--  MediHub seed.sql
--  Inserts the 6 hardcoded specialist doctors from app.js.
--  Uses INSERT IGNORE so re-running never causes duplicate errors.
--  Passwords are bcrypt hashes of "Doctor@123" (salt rounds = 10).
--  Doctors registered via the UI will be added separately.
-- ============================================================

USE medihub;

INSERT IGNORE INTO doctors
  (name, qualification, specialization, gender, mobile, email, password, experience, fee, available, initials)
VALUES
  ('Dr. Asha Kulkarni',  'MD',   'Cardiology',       'Female', '9000000001', 'asha.kulkarni@medihub.local',  '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '12 years', 700.00, 'Mon-Fri', 'AK'),
  ('Dr. Rohan Mehta',    'MBBS', 'Dermatology',      'Male',   '9000000002', 'rohan.mehta@medihub.local',    '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '8 years',  500.00, 'Mon-Sat', 'RM'),
  ('Dr. Neha Shah',      'MD',   'Pediatrics',       'Female', '9000000003', 'neha.shah@medihub.local',      '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '10 years', 600.00, 'Tue-Sun', 'NS'),
  ('Dr. Arjun Patil',   'MS',   'Orthopedics',      'Male',   '9000000004', 'arjun.patil@medihub.local',    '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '15 years', 800.00, 'Mon-Fri', 'AP'),
  ('Dr. Sana Khan',      'MBBS', 'General Medicine',  'Female', '9000000005', 'sana.khan@medihub.local',      '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '7 years',  400.00, 'Daily',   'SK'),
  ('Dr. Vivek Rao',      'MD',   'Neurology',         'Male',   '9000000006', 'vivek.rao@medihub.local',      '$2a$10$Wzr3pQH9sMWbVG6iD1Td5uLiaCn9lW5ULZ6JfXrT0vFXHWixLwH5i', '11 years', 900.00, 'Mon-Sat', 'VR');
