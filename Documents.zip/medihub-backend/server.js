
'use strict';
require('dotenv').config();

const express = require('express');
const cors = require('cors');

const authPatientRouter = require('./routes/authPatient');
const authDoctorRouter = require('./routes/authDoctor');
const resetPasswordRouter = require('./routes/resetPassword');
const appointmentsRouter = require('./routes/appointments');
const doctorsRouter = require('./routes/doctors');
const ambulanceRouter = require('./routes/ambulance');
const recordsRouter = require('./routes/records');
const doctorProfileRouter = require('./routes/doctorProfile');

require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: [
    'http://localhost:5500',
    'http://127.0.0.1:5500'
  ],
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json());

app.get('/api/health', (_req, res) =>
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
);

app.use('/api/auth/patient', authPatientRouter);
app.use('/api/auth/doctor', authDoctorRouter);
app.use('/api/auth/reset-password', resetPasswordRouter);
app.use('/api/appointments', appointmentsRouter);
app.use('/api/doctors', doctorsRouter);
app.use('/api/ambulance', ambulanceRouter);
app.use('/api/ambulances', ambulanceRouter);
app.use('/api/records', recordsRouter);
app.use('/api/doctor', doctorProfileRouter);

app.get('/api/test', (_req, res) => {
  res.send('MediHub backend connected successfully!');
});

// Keep the 404 handler after all routes.
app.use((_req, res) =>
  res.status(404).json({ message: 'Route not found.' })
);

// Global error handler
app.use((err, _req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ message: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`MediHub backend running on http://localhost:${PORT}`);
});
