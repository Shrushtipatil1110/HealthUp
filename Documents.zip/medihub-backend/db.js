'use strict';
require('dotenv').config();
const mysql = require('mysql2/promise');

// Create a connection pool — mysql2/promise gives us async/await support
const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               Number(process.env.DB_PORT) || 3306,
  user:               process.env.DB_USER     || 'root',
  password:           process.env.DB_PASSWORD || '',
  database:           process.env.DB_NAME     || 'medihub',
  waitForConnections: true,
  connectionLimit:    10,
  queueLimit:         0,
});

// Test the connection once on startup so we get an early error if credentials are wrong
pool.getConnection()
  .then(conn => { console.log('MySQL connected successfully.'); conn.release(); })
  .catch(err  => { console.error('MySQL connection error:', err.message); process.exit(1); });

module.exports = pool;
