# MediHub frontend prototype

A multi-page healthcare portal frontend using HTML, CSS and vanilla JavaScript. It is designed for testing the UI and user flows before database integration.

## Run locally
1. Extract the ZIP into a folder.
2. Open the folder in VS Code.
3. Recommended: install the **Live Server** extension and choose **Open with Live Server** on `index.html`. You can also open `index.html` directly in a modern browser.
4. Register a patient account, then use the patient dashboard. Register a separate doctor account using the Doctor tab; use the doctor login page to test the doctor portal.

## Pages included
- `login.html`, `registration.html`, `forgot-password.html`
- `doctor-login.html`, `doctor-registration.html`
- `dashboard.html`, `appointment.html`, `appointments.html`
- `specialist.html`, `ambulance.html`, `records.html`
- `doctor-dashboard.html`, `doctor-appointments.html`, `patients.html`, `doctor-profile.html`

## Current demo behavior
- Forms validate required fields.
- Patient and doctor accounts are stored separately in browser `localStorage`.
- Appointment requests, medical record notes and ambulance demo requests are saved locally.
- Doctor appointments can be accepted or rejected. Patient and doctor views use the same browser storage.
- Search and specialty filtering work on the specialist page.
- Logout clears the current session, but keeps the local demo account data.

## Important limitations before database integration
- This is **not production-ready**. Browser localStorage is not a secure database, is editable by the user, and does not synchronize between different devices or browsers. Passwords are stored in plain text for this isolated demo only. Do not enter real patient data or real passwords.
- The ambulance form does not contact or dispatch an ambulance. In an actual emergency, call local emergency services.
- The listed doctor profiles are sample UI data, not verified medical professionals.
- Existing HTML in the original upload used AngularJS, which is end-of-life. This frontend prototype uses plain JavaScript so it is simpler to connect to backend APIs; the previous files are not overwritten.

## Suggested database integration later
Keep the UI pages and replace localStorage calls in `app.js` with API calls to a backend. Add server-side authentication, password hashing, authorization by role, input validation, audit logging, and appropriate privacy protections before storing any real health information.
