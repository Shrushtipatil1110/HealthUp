
(() => {
  const $ = (s, root = document) => root.querySelector(s);

  const get = (key, fallback) => {
    try {
      return JSON.parse(localStorage.getItem(key)) ?? fallback;
    } catch {
      return fallback;
    }
  };

  const set = (key, value) =>
    localStorage.setItem(key, JSON.stringify(value));

  const patient = () => get('mediHubPatient', null);
  const doctor = () => get('mediHubDoctor', null);
  const current = () => get('mediHubSession', null);
  const appointments = () => get('mediHubAppointments', []);

  const specialists = [
    { name: 'Dr. Asha Kulkarni', specialty: 'Cardiology', experience: '12 years', fee: 700, available: 'Mon–Fri', initials: 'AK' },
    { name: 'Dr. Rohan Mehta', specialty: 'Dermatology', experience: '8 years', fee: 500, available: 'Mon–Sat', initials: 'RM' },
    { name: 'Dr. Neha Shah', specialty: 'Pediatrics', experience: '10 years', fee: 600, available: 'Tue–Sun', initials: 'NS' },
    { name: 'Dr. Arjun Patil', specialty: 'Orthopedics', experience: '15 years', fee: 800, available: 'Mon–Fri', initials: 'AP' },
    { name: 'Dr. Sana Khan', specialty: 'General Medicine', experience: '7 years', fee: 400, available: 'Daily', initials: 'SK' },
    { name: 'Dr. Vivek Rao', specialty: 'Neurology', experience: '11 years', fee: 900, available: 'Mon–Sat', initials: 'VR' }
  ];

  const esc = s =>
    String(s ?? '').replace(/[&<>"']/g, c => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[c]));

  const go = url => {
    location.href = url;
  };

  const page = document.body.dataset.page || 'login';
  const app = $('#app');

  const nav = (role = 'patient') => `
    <aside class="sidebar">
      <a class="brand" href="${role === 'doctor' ? 'doctor-dashboard.html' : 'dashboard.html'}">
        <img src="assets/logo.png" alt="MediHub">
        <span><b>MediHub</b><small>Your Health, Our Priority</small></span>
      </a>
      <div class="nav-label">WORKSPACE</div>
      ${(role === 'doctor'
        ? [
            ['doctor-dashboard.html', '▦', 'Overview'],
            ['doctor-appointments.html', '▣', 'Appointments'],
            ['patients.html', '♙', 'Patients'],
            ['doctor-profile.html', '⚕', 'My profile']
          ]
        : [
            ['dashboard.html', '▦', 'Overview'],
            ['appointment.html', '＋', 'Book appointment'],
            ['appointments.html', '▣', 'My appointments'],
            ['specialist.html', '⚕', 'Find a doctor'],
            ['ambulance.html', '🚑', 'Ambulance'],
            ['records.html', '▤', 'Medical records']
          ]
      ).map(([url, icon, label]) => `
        <a class="nav-link ${location.pathname.endsWith(url) ? 'active' : ''}" href="${url}">
          <span>${icon}</span>${label}
        </a>
      `).join('')}
      <div class="sidebar-bottom">
        <div class="secure-note"></div>
        <button class="btn btn-quiet full" id="logout">↪ Log out</button>
      </div>
    </aside>
  `;

  // FIXED: Logout logic runs only when the logout button is clicked.
  const shell = (title, subtitle, content, role = 'patient') => {
    const account = role === 'doctor' ? doctor() : patient();
    const accountName = account?.name || (role === 'doctor' ? 'Doctor' : 'Guest');
    const initials = accountName.split(' ').map(x => x[0]).slice(0, 2).join('');

    app.innerHTML = `
      ${nav(role)}
      <main class="main">
        <header class="topbar">
          <div>
            <div class="eyebrow">MEDIHUB / ${role === 'doctor' ? 'DOCTOR PORTAL' : 'PATIENT PORTAL'}</div>
            <h1>${title}</h1>
            <p>${subtitle}</p>
          </div>
          <div class="user-chip">
            <div class="avatar">${esc(initials || (role === 'doctor' ? 'D' : 'P'))}</div>
            <div>
              <b>${esc(accountName)}</b>
              <small>${role === 'doctor' ? 'Doctor account' : 'Patient account'}</small>
            </div>
          </div>
        </header>
        ${content}
        <footer>© 2026 MediHub · Healthcare, made simpler</footer>
      </main>
    `;

    $('#logout')?.addEventListener('click', () => {
      localStorage.removeItem('mediHubSession');
      localStorage.removeItem('mediHubToken');
      localStorage.removeItem('mediHubDoctorToken');
      localStorage.removeItem('mediHubPatient');
      localStorage.removeItem('mediHubDoctor');
      go('login.html');
    });
  };

  const card = (icon, title, desc, url, label, color = 'mint') => `
    <article class="service-card">
      <div class="service-icon ${color}">${icon}</div>
      <h3>${title}</h3>
      <p>${desc}</p>
      <a class="btn btn-primary" href="${url}">${label} <span>→</span></a>
    </article>
  `;

  const empty = (title, text, url, label) => `
    <div class="empty">
      <div class="empty-icon">▤</div>
      <h3>${title}</h3>
      <p>${text}</p>
      <a class="btn btn-primary" href="${url}">${label}</a>
    </div>
  `;

  const ensureRole = role => {
    const s = current();

    if (!s || s.role !== role) {
      go('login.html');
      return false;
    }

    return true;
  };

  async function authPage(kind) {
    const isLogin = kind.includes('login');
    const isDoctor = kind.includes('doctor');

    const title = isLogin
      ? 'Welcome back'
      : isDoctor
        ? 'Create your doctor account'
        : 'Create your patient account';

    app.innerHTML = `
      <div class="auth-layout">
        <section class="auth-art">
          <a class="brand brand-light" href="login.html">
            <img src="assets/logo.png" alt="MediHub">
            <span><b>MediHub</b><small>Your Health, Our Priority</small></span>
          </a>
          <div class="art-copy">
            <span class="pill">CARE THAT CONNECTS</span>
            <h1>Healthcare that puts <em>you first.</em></h1>
            <p>Appointments, doctors and essential health information — thoughtfully brought together in one place.</p>
            <div class="art-stats">
              <div><b>24/7</b><small>Access to your portal</small></div>
              <div><b>One place</b><small>For your care journey</small></div>
            </div>
          </div>
          <div class="art-foot"></div>
        </section>

        <section class="auth-side">
          <div class="auth-card">
            <div class="eyebrow">${isLogin ? 'YOUR ACCOUNT' : 'GET STARTED'}</div>
            <h2>${title}</h2>
            <p class="muted">${isLogin
              ? 'Sign in to continue to your MediHub portal.'
              : 'Fill in your details to set up your demo account.'}</p>

            <div class="role-switch">
              <a class="${!isDoctor ? 'selected' : ''}" href="${isLogin ? 'login.html' : 'registration.html'}">Patient</a>
              <a class="${isDoctor ? 'selected' : ''}" href="${isLogin ? 'doctor-login.html' : 'doctor-registration.html'}">Doctor</a>
            </div>

            <form id="auth-form" novalidate>
              ${!isLogin ? `
                <label>Full name
                  <input name="name" required placeholder="Enter your full name">
                </label>
              ` : ''}

              ${isDoctor && !isLogin ? `
                <div class="form-grid">
                  <label>Qualification
                    <select name="qualification" required>
                      <option value="">Select</option>
                      <option>MBBS</option>
                      <option>BHMS</option>
                      <option>BAMS</option>
                      <option>MD</option>
                      <option>MS</option>
                    </select>
                  </label>
                  <label>Specialization
                    <select name="specialization" required>
                      <option value="">Select</option>
                      <option>General Medicine</option>
                      <option>Cardiology</option>
                      <option>Dermatology</option>
                      <option>Pediatrics</option>
                      <option>Orthopedics</option>
                      <option>Neurology</option>
                      <option>Other</option>
                    </select>
                  </label>
                </div>
              ` : ''}

              ${!isLogin && !isDoctor ? `
                <div class="form-grid">
                  <label>Age
                    <input type="number" name="age" min="1" max="120" required placeholder="Age">
                  </label>
                  <label>Gender
                    <select name="gender" required>
                      <option value="">Select</option>
                      <option>Female</option>
                      <option>Male</option>
                      <option>Other</option>
                    </select>
                  </label>
                </div>
                <label>Address
                  <input name="address" required placeholder="City / address">
                </label>
              ` : ''}

              <label>Mobile number
                <input name="mobile" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" required placeholder="10-digit mobile number">
              </label>

              ${!isLogin ? `
                <label>Email address
                  <input name="email" type="email" required placeholder="you@example.com">
                </label>
              ` : ''}

              <label>Password
                <input name="password" type="password" minlength="8" required placeholder="At least 8 characters">
              </label>

              ${isLogin ? `
                <div class="form-row">
                  <label class="check"><input type="checkbox" id="show-password"> Show password</label>
                  <a href="forgot-password.html">Forgot password?</a>
                </div>
              ` : `<small class="hint">Use at least 8 characters.</small>`}

              <div class="form-error" id="form-error" role="alert"></div>
              <button class="btn btn-primary full" type="submit">
                ${isLogin ? 'Sign in' : 'Create account'} <span>→</span>
              </button>
            </form>

            <div class="auth-bottom">
              ${isLogin ? 'New to MediHub?' : 'Already have an account?'}
              <a href="${isLogin
                ? (isDoctor ? 'doctor-registration.html' : 'registration.html')
                : (isDoctor ? 'doctor-login.html' : 'login.html')}">
                ${isLogin ? 'Create an account' : 'Sign in'}
              </a>
            </div>

            <div class="demo-warning">MediHub · Secure account authentication</div>
          </div>
        </section>
      </div>
    `;

    $('#show-password')?.addEventListener('change', e => {
      const p = $('input[name=password]');
      if (p) p.type = e.target.checked ? 'text' : 'password';
    });

    $('#auth-form').addEventListener('submit', async e => {
      e.preventDefault();

      const f = e.currentTarget;

      if (!f.reportValidity()) return;

      const d = Object.fromEntries(new FormData(f));
      const err = $('#form-error');
      const btn = f.querySelector('button[type="submit"]');

      err.textContent = '';
      btn.disabled = true;

      try {
        const endpoint = isDoctor
          ? (isLogin ? '/api/auth/doctor/login' : '/api/auth/doctor/register')
          : (isLogin ? '/api/auth/patient/login' : '/api/auth/patient/register');

        const response = await fetch('http://localhost:3000' + endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(d)
        });

        const result = await response.json();

        if (!response.ok) {
          err.textContent = result.message || result.error || 'Registration or login failed.';
          return;
        }

        if (!result.token) {
          err.textContent = 'The server did not return an authentication token.';
          return;
        }

        if (isDoctor) {
          const doc = result.doctor;

          if (!doc || !doc.id) {
            err.textContent = 'Doctor details are missing from the server response.';
            console.error('Invalid doctor response:', result);
            return;
          }

          localStorage.setItem('mediHubDoctorToken', result.token);
          set('mediHubDoctor', doc);

          set('mediHubSession', {
            role: 'doctor',
            id: doc.id,
            name: doc.name,
            mobile: doc.mobile
          });

          go('doctor-dashboard.html');
          return;
        }

        const p = result.patient;

        if (!p || !p.id) {
          err.textContent = 'Patient details are missing from the server response.';
          console.error('Invalid patient response:', result);
          return;
        }

        localStorage.setItem('mediHubToken', result.token);
        set('mediHubPatient', p);

        set('mediHubSession', {
          role: 'patient',
          id: p.id,
          name: p.name,
          mobile: p.mobile
        });

        go('dashboard.html');

      } catch (error) {
        console.error('Authentication error:', error);
        err.textContent = 'Unable to connect to the server. Check that the MediHub backend is running.';
      } finally {
        btn.disabled = false;
      }
    });
  }

  function appointmentTable(rows, doctorView) {
    return `
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Doctor / Patient</th>
              <th>Specialty</th>
              <th>Date & time</th>
              <th>Status</th>
              ${doctorView ? '<th>Action</th>' : ''}
            </tr>
          </thead>
          <tbody>
            ${rows.map(a => `
              <tr>
                <td>
                  <b>${esc(doctorView ? a.patientName : a.doctorName)}</b>
                  <small>${esc(doctorView ? a.patientMobile : 'Appointment request')}</small>
                </td>
                <td>${esc(a.specialization)}</td>
                <td>${esc(a.date)}<small>${esc(a.time)}</small></td>
                <td><span class="status ${String(a.status || 'Pending').toLowerCase()}">${esc(a.status || 'Pending')}</span></td>
                ${doctorView ? `
                  <td>
                    ${a.status === 'Pending'
                      ? `<button class="btn btn-small" data-status="Accepted" data-id="${esc(a.id)}">Accept</button>
                         <button class="btn btn-small btn-danger" data-status="Rejected" data-id="${esc(a.id)}">Reject</button>`
                      : '—'}
                  </td>
                ` : ''}
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function dashboard() {
    if (!ensureRole('patient')) return;

    const a = appointments().filter(x => x.patientMobile === patient()?.mobile);

    shell(
      `Good day, ${esc(patient()?.name?.split(' ')[0] || 'there')} 👋`,
      'Here is your personal healthcare overview.',
      `
        <section class="welcome-banner">
          <div>
            <span class="pill">YOUR HEALTH, IN ONE PLACE</span>
            <h2>Small steps today. Healthier tomorrows.</h2>
            <p>Manage appointments and stay connected with your care team.</p>
            <a class="btn btn-white" href="appointment.html">Book an appointment →</a>
          </div>
          <div class="banner-symbol">✚</div>
        </section>

        <section class="stats-grid">
          <div class="stat-card"><span>Upcoming appointments</span><b>${a.filter(x => x.status === 'Pending' || x.status === 'Accepted').length}</b><small>Appointments to keep track of</small></div>
          <div class="stat-card"><span>Available specialists</span><b>${specialists.length}</b><small>Across popular specialties</small></div>
          <div class="stat-card"><span>Ambulance requests</span><b>${get('mediHubAmbulances', []).filter(x => x.patientMobile === patient()?.mobile).length}</b><small>Requests from this device</small></div>
        </section>

        <div class="section-heading"><div><h2>Healthcare services</h2><p>Choose what you need today.</p></div></div>
        <section class="service-grid">
          ${card('▣', 'Book appointment', 'Choose a doctor, date and time.', 'appointment.html', 'Book now')}
          ${card('✚', 'Find a specialist', 'Explore doctors by specialty.', 'specialist.html', 'Find a doctor', 'blue')}
          ${card('🚑', 'Ambulance', 'Submit an ambulance request.', 'ambulance.html', 'Request help', 'rose')}
          ${card('▤', 'Medical records', 'Keep track of your health notes.', 'records.html', 'View records', 'gold')}
        </section>

        <section class="panel">
          <div class="section-heading"><div><h2>Next appointment</h2><p>Your latest appointment request.</p></div><a class="text-link" href="appointments.html">View all →</a></div>
          ${a.length
            ? appointmentTable(a.slice().sort((x, y) => String(x.date).localeCompare(String(y.date))).slice(0, 3), false)
            : empty('No appointments yet', 'When you book a doctor, the details will appear here.', 'appointment.html', 'Book your first appointment')}
        </section>
      `
    );
  }

  async function appointmentPage() {
    if (!ensureRole('patient')) return;

    shell('Book an appointment', 'Find a suitable time with a healthcare professional.', `
      <div class="content-grid">
        <section class="panel">
          <div class="eyebrow">APPOINTMENT REQUEST</div>
          <h2>Tell us what you need</h2>
          <p class="muted">Choose a doctor and a convenient time.</p>

          <form id="appointment-form" class="stack-form">
            <label>Doctor
              <select name="doctor" id="doctor-choice" required>
                <option value="">Loading doctors...</option>
              </select>
            </label>

            <div class="form-grid">
              <label>Appointment date
                <input type="date" name="date" min="${new Date().toLocaleDateString('en-CA')}" required>
              </label>
              <label>Preferred time
                <select name="time" required>
                  <option value="">Select time</option>
                  ${[
                    ['09:00:00', '09:00 AM'],
                    ['10:00:00', '10:00 AM'],
                    ['11:00:00', '11:00 AM'],
                    ['12:00:00', '12:00 PM'],
                    ['14:00:00', '02:00 PM'],
                    ['15:00:00', '03:00 PM'],
                    ['16:00:00', '04:00 PM'],
                    ['17:00:00', '05:00 PM']
                  ].map(t => `<option value="${t[0]}">${t[1]}</option>`).join('')}
                </select>
              </label>
            </div>

            <label>Reason for visit
              <textarea name="reason" rows="4" required placeholder="Briefly describe the reason for your visit"></textarea>
            </label>
            <div class="form-error" id="form-error"></div>
            <button class="btn btn-primary" id="appointment-submit" type="submit">Submit appointment request →</button>
          </form>
        </section>

        <aside class="panel soft-panel">
          <div class="service-icon mint">♡</div>
          <h3>Before your visit</h3>
          <ul class="check-list">
            <li>Keep a list of current medicines.</li>
            <li>Bring any relevant reports or records.</li>
            <li>Arrive a little early for your appointment.</li>
          </ul>
          <p class="hint">For a medical emergency, contact your local emergency service.</p>
        </aside>
      </div>
    `);

    const form = $('#appointment-form');
    const choice = $('#doctor-choice');
    const errorBox = $('#form-error');
    const submit = $('#appointment-submit');

    let doctors = [];

    try {
      const response = await fetch('http://localhost:3000/api/doctors', {
        headers: {
          Authorization: 'Bearer ' + localStorage.getItem('mediHubToken')
        }
      });

      if (!response.ok) throw new Error('Could not load doctors. Please log in again.');

      doctors = await response.json();

      choice.innerHTML = '<option value="">Select a doctor</option>' +
        doctors.map(d => `<option value="${esc(d.id)}">${esc(d.name)} — ${esc(d.specialty)}</option>`).join('');

      if (!doctors.length) {
        choice.innerHTML = '<option value="">No doctors available</option>';
      }
    } catch (error) {
      console.error('Load doctors error:', error);
      choice.innerHTML = '<option value="">Unable to load doctors</option>';
      errorBox.textContent = error.message;
      submit.disabled = true;
      return;
    }

    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (!form.reportValidity()) return;

      const data = Object.fromEntries(new FormData(form));
      const selectedDoctor = doctors.find(d => String(d.id) === data.doctor);

      if (!selectedDoctor) {
        errorBox.textContent = 'Please select a valid doctor.';
        return;
      }

      errorBox.textContent = '';
      submit.disabled = true;
      submit.textContent = 'Submitting...';

      try {
        const response = await fetch('http://localhost:3000/api/appointments', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + localStorage.getItem('mediHubToken')
          },
          body: JSON.stringify({
            doctorId: selectedDoctor.id,
            date: data.date,
            time: data.time,
            reason: data.reason
          })
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.message || 'Unable to save appointment.');

        const all = appointments();
        if (result.appointment) all.push(result.appointment);
        set('mediHubAppointments', all);

        alert('Appointment request saved successfully!');
        go('appointments.html');
      } catch (error) {
        console.error('Book appointment error:', error);
        errorBox.textContent = error.message || 'Unable to connect to the server.';
      } finally {
        submit.disabled = false;
        submit.textContent = 'Submit appointment request →';
      }
    });
  }

  async function appointmentsPage() {
    if (!ensureRole('patient')) return;

    shell('My appointments', 'Track the status of your appointment requests.', `
      <section class="panel">
        <div class="section-heading">
          <div><h2>Appointment history</h2><p>Your appointment requests and their current status.</p></div>
          <a class="btn btn-primary" href="appointment.html">＋ Book appointment</a>
        </div>
        <div id="appointments-content">Loading appointments...</div>
      </section>
    `);

    const container = $('#appointments-content');

    try {
      const response = await fetch('http://localhost:3000/api/appointments/mine', {
        headers: {
          Authorization: 'Bearer ' + localStorage.getItem('mediHubToken')
        }
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Unable to load appointments.');

      const rows = data.map(a => ({
        ...a,
        date: typeof a.date === 'string' ? a.date.slice(0, 10) : a.date,
        time: typeof a.time === 'string' ? a.time.slice(0, 8) : a.time
      }));

      container.innerHTML = rows.length
        ? appointmentTable(rows, false)
        : empty('No appointments found', 'Your appointment requests will appear here.', 'appointment.html', 'Book appointment');
    } catch (error) {
      console.error('Load appointments error:', error);
      container.innerHTML = '<p class="form-error">Unable to load appointments. Check the backend connection and log in again if needed.</p>';
    }
  }

  async function specialistPage() {
    if (!ensureRole('patient')) return;

    shell('Find a specialist', 'Explore doctors and choose the care that fits your needs.', `
      <section class="panel filter-row">
        <label>Search doctor or specialty
          <input id="doctor-search" placeholder="Try cardiology, Dr. Asha...">
        </label>
        <label>Specialty
          <select id="specialty-filter"><option value="">All specialties</option></select>
        </label>
      </section>
      <section id="doctor-grid" class="doctor-grid"><p>Loading doctors...</p></section>
    `);

    const grid = $('#doctor-grid');
    const search = $('#doctor-search');
    const filter = $('#specialty-filter');

    try {
      const response = await fetch('http://localhost:3000/api/doctors', {
        headers: {
          Authorization: 'Bearer ' + localStorage.getItem('mediHubToken')
        }
      });

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          grid.innerHTML = empty('Login required', 'Please log in again to view specialists.', 'login.html', 'Login');
          return;
        }
        throw new Error('Unable to load doctors. Status: ' + response.status);
      }

      const doctors = await response.json();

      filter.innerHTML = '<option value="">All specialties</option>' +
        [...new Set(doctors.map(d => d.specialty).filter(Boolean))]
          .map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('');

      const draw = () => {
        const q = search.value.toLowerCase().trim();
        const sp = filter.value;

        const list = doctors.filter(d =>
          (String(d.name || '') + ' ' + String(d.specialty || '')).toLowerCase().includes(q) &&
          (!sp || d.specialty === sp)
        );

        grid.innerHTML = list.length ? list.map(d => `
          <article class="doctor-card">
            <div class="doctor-head">
              <div class="doctor-avatar">${esc(d.initials || String(d.name || 'D').split(' ').map(w => w[0]).slice(0, 2).join(''))}</div>
              <span class="available">● Available</span>
            </div>
            <h3>${esc(d.name || 'Doctor')}</h3>
            <p class="specialty">${esc(d.specialty || 'General Medicine')}</p>
            <div class="doctor-meta">
              <span>◷ ${esc(d.experience || 'Not specified')} experience</span>
              <span>₹${esc(d.fee ?? 0)} <small>consultation</small></span>
            </div>
            <p class="hint">Availability: ${esc(d.available || 'Contact for details')}</p>
            <a class="btn btn-primary full" href="appointment.html">Book appointment →</a>
          </article>
        `).join('') : empty('No matching doctors', 'Try a different search or specialty.', 'specialist.html', 'Clear search');
      };

      search.addEventListener('input', draw);
      filter.addEventListener('change', draw);
      draw();
    } catch (error) {
      console.error('Specialist page error:', error);
      grid.innerHTML = '<p>Unable to load doctors. Check that the MediHub backend is running and try again.</p>';
    }
  }

  async function ambulancePage() {
  if (!ensureRole('patient')) return;

  shell('Ambulance assistance', 'Submit a request and review your saved requests.', `
    <div class="content-grid">
      <section class="panel">
        <div class="service-icon rose">🚑</div>
        <h2>Request an ambulance</h2>
         <form id="ambulance-form" class="stack-form">
          <label>Pickup address
            <input name="address" required placeholder="Street, area, landmark">
          </label>
          <label>Contact number
            <input name="phone" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" required value="${esc(patient()?.mobile || '')}">
          </label>
          <label>Urgency
            <select name="urgency" required>
              <option value="Routine transport">Routine transport</option>
              <option value="Urgent">Urgent</option>
              <option value="Emergency — call emergency services now">Emergency — call emergency services now</option>
            </select>
          </label>
          <label>Additional details
            <textarea name="details" rows="3" placeholder="Optional details"></textarea>
          </label>
          <div class="form-error" id="form-error"></div>
          <button class="btn btn-primary" type="submit">Save ambulance request →</button>
        </form>
      </section>
      <aside class="panel soft-panel">
       
        
      </aside>
    </div>
    <section class="panel">
      <h2>My requests</h2>
      <div id="ambulance-list">Loading requests...</div>
    </section>
  `);

  const form = $('#ambulance-form');
  const errorBox = $('#form-error');
  const list = $('#ambulance-list');
  const token = localStorage.getItem('mediHubToken');

  if (!token) {
    errorBox.textContent = 'Please log in again.';
    list.textContent = 'Patient authentication is missing.';
    return;
  }

  async function loadRequests() {
    const response = await fetch('http://localhost:3000/api/ambulances/mine', {
      headers: { Authorization: 'Bearer ' + token }
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Unable to load requests.');

    list.innerHTML = data.length ? `
      <div class="request-list">
        ${data.map(a => `
          <div class="request-item">
            <div class="service-icon rose">🚑</div>
            <div>
              <b>${esc(a.address)}</b>
              <p>${esc(a.urgency)} · ${esc(a.createdAt ? new Date(a.createdAt).toLocaleString() : '')}</p>
              <small>Status: ${esc(a.status || 'Requested')}</small>
            </div>
          </div>
        `).join('')}
      </div>
    ` : empty('No requests yet', 'Your saved requests will appear here.', 'ambulance.html', 'Refresh');
  }

  try {
    await loadRequests();
  } catch (error) {
    console.error('Load ambulance requests:', error);
    list.innerHTML = `<p class="form-error">${esc(error.message)}</p>`;
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (!form.reportValidity()) return;

    const button = form.querySelector('button[type="submit"]');
    const data = Object.fromEntries(new FormData(form));

    errorBox.textContent = '';
    button.disabled = true;
    button.textContent = 'Saving...';

    try {
      const response = await fetch('http://localhost:3000/api/ambulances', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify(data)
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Unable to save request.');

      alert('Ambulance request send.');
      await loadRequests();
      form.reset();
      const phone = form.querySelector('[name="phone"]');
      if (phone) phone.value = patient()?.mobile || '';
    } catch (error) {
      console.error('Save ambulance request:', error);
      errorBox.textContent = error.message || 'Unable to connect to the backend.';
    } finally {
      button.disabled = false;
      button.textContent = 'Save ambulance request →';
    }
  });
}

  async function recordsPage() {
  if (!ensureRole('patient')) return;

  shell('Medical records', 'Manage your saved health notes.', `
    <section class="panel">
      <h2>Add a record note</h2>
      <form id="record-form" class="form-grid">
        <label>Record title
          <input name="title" required placeholder="e.g. Annual check-up">
        </label>
        <label>Date
          <input type="date" name="date" required value="${new Date().toISOString().slice(0, 10)}">
        </label>
        <label class="span-2">Notes
          <textarea name="notes" rows="3" required placeholder="Add a short summary or reminder"></textarea>
        </label>
        <div class="span-2">
          <div class="form-error" id="record-error"></div>
          <button class="btn btn-primary" type="submit">＋ Save record note</button>
        </div>
      </form>
      </section>
    <section class="panel">
      <div class="section-heading">
        <div><h2>My records</h2><p id="record-count">Loading records...</p></div>
      </div>
      <div id="records-list">Loading records...</div>
    </section>
  `);

  const form = $('#record-form');
  const errorBox = $('#record-error');
  const list = $('#records-list');
  const count = $('#record-count');
  const token = localStorage.getItem('mediHubToken');

  if (!token) {
    errorBox.textContent = 'Please log in again.';
    list.textContent = 'Patient authentication is missing.';
    return;
  }

  async function loadRecords() {
    const response = await fetch('http://localhost:3000/api/records/mine', {
      headers: { Authorization: 'Bearer ' + token }
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Unable to load medical records.');

    count.textContent = `${data.length} saved record(s)`;

    list.innerHTML = data.length ? `
      <div class="record-list">
        ${data.map(r => `
          <article class="record-item">
            <div class="record-icon">▤</div>
            <div class="record-copy">
              <b>${esc(r.title)}</b>
              <small>${esc(typeof r.date === 'string' ? r.date.slice(0, 10) : '')}</small>
              <p>${esc(r.notes)}</p>
            </div>
            <button class="btn btn-small btn-danger" data-delete-record="${esc(r.id)}">Delete</button>
          </article>
        `).join('')}
      </div>
    ` : empty('No records added', 'Add a note above to see it here.', 'records.html', 'Refresh');

    list.querySelectorAll('[data-delete-record]').forEach(button => {
      button.addEventListener('click', async () => {
        if (!confirm('Delete this record permanently?')) return;

        button.disabled = true;

        try {
          const response = await fetch(
            'http://localhost:3000/api/records/' + encodeURIComponent(button.dataset.deleteRecord),
            {
              method: 'DELETE',
              headers: { Authorization: 'Bearer ' + token }
            }
          );

          const result = await response.json();
          if (!response.ok) throw new Error(result.message || 'Unable to delete record.');

          await loadRecords();
        } catch (error) {
          alert(error.message || 'Unable to delete record.');
          button.disabled = false;
        }
      });
    });
  }

  try {
    await loadRecords();
  } catch (error) {
    console.error('Load medical records:', error);
    list.innerHTML = `<p class="form-error">${esc(error.message)}</p>`;
    count.textContent = 'Unable to load records';
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (!form.reportValidity()) return;

    const button = form.querySelector('button[type="submit"]');
    const data = Object.fromEntries(new FormData(form));

    errorBox.textContent = '';
    button.disabled = true;
    button.textContent = 'Saving...';

    try {
      const response = await fetch('http://localhost:3000/api/records', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token
        },
        body: JSON.stringify(data)
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Unable to save record.');

      form.reset();
      form.querySelector('[name="date"]').value = new Date().toISOString().slice(0, 10);

      await loadRecords();
    } catch (error) {
      console.error('Save medical record:', error);
      errorBox.textContent = error.message || 'Unable to save record.';
    } finally {
      button.disabled = false;
      button.textContent = '＋ Save record note';
    }
  });
}

  function doctorDashboard() {
    if (!ensureRole('doctor')) return;

    const d = doctor();
    const rows = appointments();

    shell(`Welcome, ${esc(d?.name || 'Doctor')}`, 'Your practice overview and appointment requests.', `
      <section class="welcome-banner doctor-banner">
        <div>
          <span class="pill">DOCTOR WORKSPACE</span>
          <h2>Good care starts with a clear schedule.</h2>
          <p>Review requests and keep your profile details up to date.</p>
          <a class="btn btn-white" href="doctor-appointments.html">Review appointments →</a>
        </div>
        <div class="banner-symbol">⚕</div>
      </section>

      <section class="stats-grid">
        <div class="stat-card"><span>Total requests</span><b>${rows.length}</b><small>All appointment requests</small></div>
        <div class="stat-card"><span>Pending</span><b>${rows.filter(a => a.status === 'Pending').length}</b><small>Need your review</small></div>
        <div class="stat-card"><span>Accepted</span><b>${rows.filter(a => a.status === 'Accepted').length}</b><small>Confirmed in demo</small></div>
      </section>

      <section class="service-grid">
        ${card('▣', 'Appointments', 'Review, accept or reject requests.', 'doctor-appointments.html', 'Manage requests')}
        ${card('♙', 'Patients', 'See patient details from requests.', 'patients.html', 'View patients', 'blue')}
        ${card('⚕', 'My profile', 'Review your registered information.', 'doctor-profile.html', 'View profile', 'gold')}
      </section>

      <section class="panel">
        <div class="section-heading"><div><h2>Recent appointment requests</h2><p>Latest requests assigned to your doctor account.</p></div><a class="text-link" href="doctor-appointments.html">View all →</a></div>
        ${rows.length ? appointmentTable(rows.slice(-5).reverse(), true) : empty('No requests yet', 'Patient requests will appear here when available.', 'doctor-appointments.html', 'View appointments')}
      </section>
    `, 'doctor');
  }

  async function doctorAppointments() {
    if (!ensureRole('doctor')) return;

    shell('Appointment requests', 'Review patient requests and update their status.', `
      <section class="panel"><div id="doctor-appointments-content">Loading appointment requests...</div></section>
    `, 'doctor');

    const container = $('#doctor-appointments-content');
    const token = localStorage.getItem('mediHubDoctorToken');

    if (!token) {
      container.innerHTML = '<p class="form-error">Doctor authentication is missing. Please sign in again.</p>';
      return;
    }

    async function loadRequests() {
      const response = await fetch('http://localhost:3000/api/appointments/doctor', {
        headers: { Authorization: 'Bearer ' + token }
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Unable to load requests.');

      const rows = data.map(a => ({
        ...a,
        date: typeof a.date === 'string' ? a.date.slice(0, 10) : a.date,
        time: typeof a.time === 'string' ? a.time.slice(0, 8) : a.time
      }));

      container.innerHTML = rows.length
        ? appointmentTable(rows, true)
        : empty('No appointment requests', 'Requests will appear when patients book your doctor profile.', 'doctor-dashboard.html', 'Back to overview');

      container.querySelectorAll('[data-status]').forEach(button => {
        button.addEventListener('click', async () => {
          const id = button.dataset.id;
          const status = button.dataset.status;
          button.disabled = true;

          try {
            const response = await fetch('http://localhost:3000/api/appointments/' + encodeURIComponent(id) + '/status', {
              method: 'PATCH',
              headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + token
              },
              body: JSON.stringify({ status })
            });

            const answer = await response.json();
            if (!response.ok) throw new Error(answer.message || 'Unable to update status.');

            await loadRequests();
          } catch (error) {
            alert(error.message);
            button.disabled = false;
          }
        });
      });
    }

    try {
      await loadRequests();
    } catch (error) {
      console.error('Doctor appointments error:', error);
      container.innerHTML = `<p class="form-error">Unable to load requests: ${esc(error.message)}</p>`;
    }
  }

  function patientsPage() {
    if (!ensureRole('doctor')) return;

    const rows = appointments();
    const unique = [...new Map(rows.map(a => [a.patientMobile, a])).values()];

    shell('Patients', 'Patient details associated with your appointment requests.', `
      <section class="panel">
        ${unique.length ? `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Patient</th><th>Mobile</th><th>Appointments</th><th>Latest visit</th></tr></thead>
              <tbody>
                ${unique.map(p => `
                  <tr>
                    <td><b>${esc(p.patientName)}</b></td>
                    <td>${esc(p.patientMobile)}</td>
                    <td>${rows.filter(a => a.patientMobile === p.patientMobile).length}</td>
                    <td>${esc(p.date)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : empty('No patient details yet', 'Patient details appear here after appointment requests.', 'doctor-appointments.html', 'View appointments')}
        <p class="hint"></p>
      </section>
    `, 'doctor');
  }

  
async function doctorProfile() {
  if (!ensureRole('doctor')) return;

  const token = localStorage.getItem('mediHubDoctorToken');

  shell('My doctor profile', 'Review and update your profile information.', `
    <section class="panel profile-panel">
      <div id="profile-content">Loading doctor profile...</div>
    </section>
  `, 'doctor');

  const container = $('#profile-content');

  try {
    const response = await fetch('http://localhost:3000/api/auth/doctor/profile', {
      headers: {
        Authorization: 'Bearer ' + token
      }
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Unable to load doctor profile.');
    }

    const d = result.doctor;

    set('mediHubDoctor', d);

    container.innerHTML = `
      <div class="profile-hero">
        <div class="doctor-avatar large">
          ${esc(d.name?.split(' ').map(x => x[0]).slice(0, 2).join('') || 'DR')}
        </div>
        <div>
          <h2>${esc(d.name)}</h2>
          <p>${esc(d.specialization)} · ${esc(d.qualification)}</p>
        </div>
      </div>

      <form id="profile-form" class="form-grid">
        <label>Full name
          <input name="name" required value="${esc(d.name)}">
        </label>

        <label>Qualification
          <select name="qualification" required>
            ${['MBBS', 'BHMS', 'BAMS', 'MD', 'MS'].map(q =>
              `<option value="${q}" ${d.qualification === q ? 'selected' : ''}>${q}</option>`
            ).join('')}
          </select>
        </label>

        <label>Specialization
          <select name="specialization" required>
            ${['General Medicine', 'Cardiology', 'Dermatology', 'Pediatrics', 'Orthopedics', 'Neurology', 'Other'].map(s =>
              `<option value="${s}" ${d.specialization === s ? 'selected' : ''}>${s}</option>`
            ).join('')}
          </select>
        </label>

        <label>Gender
          <select name="gender">
            <option value="">Select gender</option>
            ${['Female', 'Male', 'Other'].map(g =>
              `<option value="${g}" ${d.gender === g ? 'selected' : ''}>${g}</option>`
            ).join('')}
          </select>
        </label>

        <label>Mobile number
          <input value="${esc(d.mobile)}" disabled>
        </label>

        <label>Email
          <input name="email" type="email" required value="${esc(d.email)}">
        </label>

        <div class="span-2">
          <div class="form-error" id="profile-error"></div>
          <button class="btn btn-primary" type="submit">Save profile changes</button>
        </div>
      </form>
    `;

    $('#profile-form').addEventListener('submit', async e => {
      e.preventDefault();

      const form = e.currentTarget;
      if (!form.reportValidity()) return;

      const button = form.querySelector('button[type="submit"]');
      const errorBox = $('#profile-error');

      button.disabled = true;
      errorBox.textContent = '';

      try {
        const response = await fetch('http://localhost:3000/api/auth/doctor/profile', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + token
          },
          body: JSON.stringify(Object.fromEntries(new FormData(form)))
        });

        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.message || 'Unable to update profile.');
        }

        set('mediHubDoctor', result.doctor);

        alert('Doctor profile updated successfully in MySQL.');
        doctorProfile();
      } catch (error) {
        console.error('Update profile error:', error);
        errorBox.textContent = error.message || 'Unable to update profile.';
      } finally {
        button.disabled = false;
      }
    });
  } catch (error) {
    console.error('Load doctor profile error:', error);
    container.innerHTML = `
      <p class="form-error">${esc(error.message)}</p>
      <button class="btn btn-primary" onclick="location.reload()">Try again</button>
    `;
  }
}


  function forgotPage() {
    app.innerHTML = `
      <div class="auth-layout">
        <section class="auth-art">
          <a class="brand brand-light" href="login.html">
            <img src="assets/logo.png" alt="MediHub">
            <span><b>MediHub</b><small>Your Health, Our Priority</small></span>
          </a>
          <div class="art-copy">
            <span class="pill">ACCOUNT SUPPORT</span>
            <h1>Let's get you <em>back on track.</em></h1>
            <p>Reset a demo account password using the mobile number you registered with.</p>
          </div>
        </section>

        <section class="auth-side">
          <div class="auth-card">
            <div class="eyebrow">PASSWORD RESET</div>
            <h2>Create a new password</h2>
            <p class="muted">Choose the account type and enter your registered mobile number.</p>

            <form id="reset-form">
              <label>Account type
                <select name="role"><option value="patient">Patient</option><option value="doctor">Doctor</option></select>
              </label>
              <label>Registered mobile<input name="mobile" pattern="[0-9]{10}" minlength="10" maxlength="10" required></label>
              <label>New password<input name="password" type="password" minlength="8" required></label>
              <div class="form-error" id="form-error"></div>
              <button class="btn btn-primary full">Reset password</button>
            </form>

            <div class="auth-bottom"><a href="login.html">← Back to sign in</a></div>
            <div class="demo-warning">Demo mode only. Real password reset requires a secure backend.</div>
          </div>
        </section>
      </div>
    `;

    $('#reset-form').addEventListener('submit', e => {
      e.preventDefault();

      const f = e.currentTarget;
      if (!f.reportValidity()) return;

      const d = Object.fromEntries(new FormData(f));
      const key = d.role === 'doctor' ? 'mediHubDoctor' : 'mediHubPatient';
      const account = get(key, null);

      if (!account || String(account.mobile) !== d.mobile) {
        $('#form-error').textContent = 'No account found with that mobile number.';
        return;
      }

      account.password = d.password;
      set(key, account);

      alert('This demo reset only changes locally stored data. For a backend account, use the backend password-reset flow.');
      go(d.role === 'doctor' ? 'doctor-login.html' : 'login.html');
    });
  }

  switch (page) {
    case 'login':
      authPage('login');
      break;
    case 'doctor-login':
      authPage('doctor-login');
      break;
    case 'registration':
      authPage('registration');
      break;
    case 'doctor-registration':
      authPage('doctor-registration');
      break;
    case 'forgot-password':
      forgotPage();
      break;
    case 'dashboard':
      dashboard();
      break;
    case 'appointment':
      appointmentPage();
      break;
    case 'appointments':
      appointmentsPage();
      break;
    case 'specialist':
      specialistPage();
      break;
    case 'ambulance':
      ambulancePage();
      break;
    case 'records':
      recordsPage();
      break;
    case 'doctor-dashboard':
      doctorDashboard();
      break;
    case 'doctor-appointments':
      doctorAppointments();
      break;
    case 'patients':
      patientsPage();
      break;
    case 'doctor-profile':
      doctorProfile();
      break;
    default:
      authPage('login');
  }
})();
